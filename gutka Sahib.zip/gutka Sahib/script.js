// ---------------hello here ---------------------

let japji = document.getElementById('japji')
let jaap = document.getElementById('jaap')
let tav = document.getElementById('tav')

let chopai = document.getElementById('chopai')
let anand = document.getElementById('anand')
let rehraas = document.getElementById('rehraas')
let ardas = document.getElementById('ardas')
let kirtan = document.getElementById('kirtan')
let sukhmani = document.getElementById('sukhmani')
let dukh = document.getElementById('dukh')

let show_japji = document.getElementById('show_japji')
let show_jaap = document.getElementById('show_jaap')
let show_tav = document.getElementById('show_tav')

let show_chopai = document.getElementById('show_chopai')
let show_anand = document.getElementById('show_anand')
let show_rehraas = document.getElementById('show_rehraas')
let show_ardas = document.getElementById('show_ardas')
let show_kirtan = document.getElementById('show_kirtan')
let show_sukhmani = document.getElementById('show_sukhmani')
let show_dukh = document.getElementById('show_dukh')

let time = document.getElementById('time')
let show_time = document.getElementById('show_time')



let about = document.getElementById('about')
let show_about = document.getElementById('show_about')
// to show japji sahib in our site 
japji.addEventListener('click', function run() {
    if (show_japji.style.display === 'none') {
        show_japji.style.display = 'block'
        show_japji.className = 'check_animation'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'
          


    }
    else {
        show_japji.style.display = 'none'
    }
})

// to show jaap sahib in our site 
jaap.addEventListener('click', function run() {
    if (show_jaap.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.className = 'check_animation'
        show_jaap.style.display = 'block'
        show_tav.style.display = 'none'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'

    }
    else {
        show_jaap.style.display = 'none'
  
    }
})

// to show tav prasad savaiye in  our site 
tav.addEventListener('click', function run() {
    if (show_tav.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'block'
        show_tav.className = 'check_animation'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'

    }
    else {
        show_tav.style.display = 'none'
    }
})

// to show chopai sahib in our site 

chopai.addEventListener('click', function run() {
    if (show_chopai.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_chopai.className = 'check_animation'
        show_chopai.style.display = 'block'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'

    }
    else {
        show_chopai.style.display = 'none'
      
    }
})

//  to show anand sahib in our site 
anand.addEventListener('click', function run() {
    if (show_anand.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_anand.className = 'check_animation'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'block'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'

    }
    else {
  
        show_anand.style.display = 'none'
        
    }
})


//  to show sukhmani sahib in our site 
sukhmani.addEventListener('click', function run() {
    if (show_sukhmani.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_sukhmani.className = 'check_animation'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'block'
        show_kirtan.style.display = 'none'

    }
    else {

        show_sukhmani.style.display = 'none'

    }
})


// to show kirtan sohila in our site 
kirtan.addEventListener('click', function run() {
    if (show_kirtan.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'block'
        show_kirtan.className = 'check_animation'

    }
    else {
    
        show_kirtan.style.display = 'none'
    }
})

//  to show rehraas sahib in our site 
rehraas.addEventListener('click', function run() {
    if (show_rehraas.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'block'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'
        show_rehraas.className = 'check_animation'

    }
    else {

        show_rehraas.style.display = 'none'
        
    }
})

ardas.addEventListener('click', function run() {
    if (show_ardas.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'none'
        show_ardas.style.display = 'block'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'
        show_ardas.className = 'check_animation'

    }
    else {
       
        show_ardas.style.display = 'none'
        
    }
})

dukh.addEventListener('click', function run() {
    if (show_rehraas.style.display === 'none') {
        show_japji.style.display = 'none'
        show_jaap.style.display = 'none'
        show_tav.style.display = 'none'
        show_chopai.style.display = 'none'
        show_anand.style.display = 'none'
        show_rehraas.style.display = 'none'
        show_dukh.style.display = 'block'
        show_ardas.style.display = 'none'
        show_sukhmani.style.display = 'none'
        show_kirtan.style.display = 'none'
        show_dukh.className = 'check_animation'

    }
    else {
      
        show_dukh.style.display = 'none'
      
    }
})





time.addEventListener('click', function run(){
    if(show_time.style.display === 'none'){
        show_time.style.display = 'block'
        show_time.className = 'check_animation'
        
    }
    else{
        show_time.style.display = 'none'
        // show_time.className = 'goes'
    }
})

about.addEventListener('click', function run(){
    console.log(about)
    if(show_about.style.display === 'none'){
        show_about.style.display = 'block'
        show_about.className = 'make_animation'
    }
    else{
        show_about.style.display = 'none'
    }
})

let light = document.getElementById( "light" )
let dark = document.getElementById('dark')
let menu_change = document.getElementById('menu_change')
let nav_change = document.getElementById('nav_change')
let content = document.getElementById('content')
let color = document.getElementById('color')

dark.addEventListener('click', function run(){
    dark.style.display = 'none'
    if(light.style.display ==='none'){
        light.style.display = 'block'
        menu_change.className = 'menu_change'
        nav_change.className = 'nav_change'
        content.className = 'content_change'
        show_about.className = 'about_change'
        show_time.className = 'time_change'
        document.className='color_change'
    
    }
    else{
        light.style.display = 'none'
        menu_change.className = 'menu_change'
        nav_change.className = 'nav_change'
        show_about.className = 'about_change'
        show_time.className = 'time_change'
        dark.style.display = 'block'

        content.className = 'content_change'
    }
})

light.addEventListener('click', function run(){
    light.style.display = 'none'
    if(dark.style.display ==='none'){
        dark.style.display = 'block'
        show_about.className = 'about_change'
        show_time.className = 'time_change'
        menu_change.className = 'menu_change2'
        nav_change.className = 'nav_change2'
        content.className = 'content_change2'
    
    }
    else{
        dark.style.display = 'none'
        menu_change.className = 'menu_change2'
        nav_change.className = 'nav_change2'
        light.style.display = 'block'
        show_about.className = 'about_change'
        show_time.className = 'time_change'
        content.className = 'content_change2'
    }
})
